# Introduction
https://mp.weixin.qq.com/s/UBVLDW2T-Y6R-0IaRfu81Q

# Environment(Tested)
```
OS: Windows10
Python: Python3.5+(have installed necessary dependencies)
```

# Usage
```
Step1:
pip install -r requirements.txt
Step2:
python Game14.py
```

# Game Display
![giphy](effect/running.gif)